from core.blueprints.base_blueprint import BaseBlueprint

explore_bp = BaseBlueprint('explore', __name__, template_folder='templates')
